import sys
import os

# Добавляем путь к проекту для тестов
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
